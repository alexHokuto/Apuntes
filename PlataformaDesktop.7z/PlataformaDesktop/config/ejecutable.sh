#!/bin/bash  
java -jar recaudacion3-tributaria-integrador-ejecutor-desktop-1.7.0.jar
